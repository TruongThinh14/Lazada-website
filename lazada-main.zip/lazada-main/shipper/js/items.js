
const activebutton = document.getElementById('btn-active');
activebutton.addEventListener('click',function() {
  activebutton.innerHTML = 'delivered';
});
/*
function registerClickHandler(e) {
  var target = e.target; 
  target.parentNode.removeChild(target.parentNode);

}
var cancelBtn = document.querySelectorAll('btn-cancel')
for (var i = 0 ; i < cancelBtn.length; i++) {
  cancelBtn[i].addEventListener("click", registerClickHandler, false); 
}
*/
var cancelitem = document.getElementsByClassName('btn-cancel');
console.log(cancelitem);
for (var i = 0; i< cancelitem.length;i++) {
  var button = cancelitem[i];
  button.addEventListener('click',function(event){
    var buttonclicked = event.target
    buttonclicked.parentElement.parentElement.remove();

  })
}